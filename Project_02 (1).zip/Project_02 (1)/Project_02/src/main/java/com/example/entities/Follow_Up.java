package com.example.entities;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="Follow_Up")
public class Follow_Up {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int FollowUp_Id;
	int Enquiry_Id;
	Date FollowUp_Date;
	int Attempts;
	int Staff_Id;
	String FollowUp_Message;
	@Column
	public int getFollowUp_Id() {
		return FollowUp_Id;
	}
	public void setFollowUp_Id(int followUp_Id) {
		FollowUp_Id = followUp_Id;
	}
	@Column
	public int getEnquiry_Id() {
		return Enquiry_Id;
	}
	public void setEnquiry_Id(int enquiry_Id) {
		Enquiry_Id = enquiry_Id;
	}
	@Column

	public Date getFollowUp_Date() {
		return FollowUp_Date;
	}
	public void setFollowUp_Date(Date followUp_Date) {
		FollowUp_Date = followUp_Date;
	}
	@Column
	public int getAttempts() {
		return Attempts;
	}
	public void setAttempts(int attempts) {
		Attempts = attempts;
	}
	@Column
	public int getStaff_Id() {
		return Staff_Id;
	}
	public void setStaff_Id(int staff_Id) {
		Staff_Id = staff_Id;
	}
	@Column
	public String getFollowUp_Message() {
		return FollowUp_Message;
	}
	public void setFollowUp_Message(String followUp_Message) {
		FollowUp_Message = followUp_Message;
	}
	@Override
	public String toString() {
		return "Follow_Up [FollowUp_Id=" + FollowUp_Id + ", Enquiry_Id=" + Enquiry_Id + ", FollowUp_Date="
				+ FollowUp_Date + ", Attempts=" + Attempts + ", Staff_Id=" + Staff_Id + ", FollowUp_Message="
				+ FollowUp_Message + "]";
	}
	
	

}
