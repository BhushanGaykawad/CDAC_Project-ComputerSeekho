package com.example.entities;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="student")
public class Student 
{
    
    int Student_Id;

    String Student_Name;

    int Enquiry_Id;

    int Batch_Id;

    Date Registration_Date;

    int Payment_id;

    String Photo;

    String Contact_No;

    String Email;

    String Gender;

    int Location_id;

    Date Date_of_Birth;

    int Qualification_id;

    int Course_id;

    double Total_fees;

    double fees_paid;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Student_Id")
    public int getStudent_Id() {
        return Student_Id;
    }

    public void setStudent_Id(int student_Id) {
        Student_Id = student_Id;
    }

    @Column(name = "Student_Name")
    public String getStudent_Name() {
        return Student_Name;
    }

    public void setStudent_Name(String student_Name) {
        Student_Name = student_Name;
    }

    @Column(name = "Enquiry_Id")
    public int getEnquiry_Id() {
        return Enquiry_Id;
    }

    public void setEnquiry_Id(int enquiry_Id) {
        Enquiry_Id = enquiry_Id;
    }

    @Column(name = "Batch_Id")
    public int getBatch_Id() {
        return Batch_Id;
    }

    public void setBatch_Id(int batch_Id) {
        Batch_Id = batch_Id;
    }

    @Column(name = "Registration_Date")
    public Date getRegistration_Date() {
        return Registration_Date;
    }

    public void setRegistration_Date(Date registration_Date) {
        Registration_Date = registration_Date;
    }

    @Column(name = "Payment_id")
    public int getPayment_id() {
        return Payment_id;
    }

    public void setPayment_id(int payment_id) {
        Payment_id = payment_id;
    }

    @Column(name = "Photo")
    public String getPhoto() {
        return Photo;
    }

    public void setPhoto(String photo) {
        Photo = photo;
    }

    @Column(name = "Contact_No")
    public String getContact_No() {
        return Contact_No;
    }

    public void setContact_No(String contact_No) {
        Contact_No = contact_No;
    }

    @Column(name = "Email")
    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    @Column(name = "Gender")
    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    @Column(name = "Location_id")
    public int getLocation_id() {
        return Location_id;
    }

    public void setLocation_id(int location_id) {
        Location_id = location_id;
    }

    @Column(name = "Date_of_Birth")
    public Date getDate_of_Birth() {
        return Date_of_Birth;
    }

    public void setDate_of_Birth(Date date_of_Birth) {
        Date_of_Birth = date_of_Birth;
    }

    @Column(name = "Qualification_id")
    public int getQualification_id() {
        return Qualification_id;
    }

    public void setQualification_id(int qualification_id) {
        Qualification_id = qualification_id;
    }

    @Column(name = "Course_id")
    public int getCourse_id() {
        return Course_id;
    }

    public void setCourse_id(int course_id) {
        Course_id = course_id;
    }

    @Column(name = "Total_fees")
    public double getTotal_fees() {
        return Total_fees;
    }

    public void setTotal_fees(double total_fees) {
        Total_fees = total_fees;
    }

    @Column(name = "fees_paid")
    public double getFees_paid() {
        return fees_paid;
    }

    public void setFees_paid(double fees_paid) {
        this.fees_paid = fees_paid;
    }


	@Override
	public String toString() {
		return "Student [Student_Id=" + Student_Id + ", Student_Name=" + Student_Name + ", Enquiry_Id=" + Enquiry_Id
				+ ", Batch_Id=" + Batch_Id + ", Registration_Date=" + Registration_Date + ", Payment_id=" + Payment_id
				+ ", Photo=" + Photo + ", Contact_No=" + Contact_No + ", Email=" + Email + ", Gender=" + Gender
				+ ", Location_id=" + Location_id + ", Date_of_Birth=" + Date_of_Birth + ", Qualification_id="
				+ Qualification_id + ", Course_id=" + Course_id + ", Total_fees=" + Total_fees + ", fees_paid="
				+ fees_paid + "]";
	}

}
