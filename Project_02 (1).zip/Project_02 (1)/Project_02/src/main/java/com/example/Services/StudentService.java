package com.example.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entities.Staff;
import com.example.entities.Student;
import com.example.repositories.StudentRepository;

@Service
public class StudentService {
	@Autowired
    public StudentRepository StudentRepo;

   

    public List<Student> getAllStudents() {
        return StudentRepo.findAll();
    }

    public Optional<Student> GetbyId(int id) {
		// TODO Auto-generated method stub
		return StudentRepo.findById(id);
	}

    public  Student addStudent(Student student) {
        return StudentRepo.save(student);
    }

//    public Student updateStudent(Long id, Student updatedStudent) {
//        Student existingStudent = getStudentById(id);
//        
//        existingStudent.setName(updatedStudent.getName());
//        existingStudent.setAge(updatedStudent.getAge());
//
//        return StudentRepo.save(existingStudent);
//    }

    public void deleteStudent(int id) {
        StudentRepo.deleteById(id);
    }

    public Optional<Student> getStudent(int id) {
		return StudentRepo.findById(id);
	}

	
}

