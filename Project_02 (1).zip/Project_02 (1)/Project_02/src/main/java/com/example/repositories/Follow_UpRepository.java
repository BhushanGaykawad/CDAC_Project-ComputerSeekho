package com.example.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entities.Follow_Up;
@Repository
public interface Follow_UpRepository extends JpaRepository<Follow_Up,Integer> {

}