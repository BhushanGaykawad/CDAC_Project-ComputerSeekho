package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entity.CourseDuration;


@Repository
public interface DurationRespository extends JpaRepository <CourseDuration,Integer>
{

}
