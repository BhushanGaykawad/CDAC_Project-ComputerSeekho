package com.example.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.entity.CourseDuration;
import com.example.entity.Qualification;
import com.example.service.DurationService;
import com.example.service.QualificationService;

@RestController
@CrossOrigin("*")
@RequestMapping("api/Qualification")
public class QualificationController 
{
	@Autowired
	private QualificationService service;
	
	
	@GetMapping(value="/ListAll")
	public List<Qualification>ListAll()
	{
		return service.getQualification();
	}
	
	@PostMapping(value = "/createqualification")
	public Qualification createDuration(@RequestBody Qualification group) {
	    return service.addQualification(group);
	}
	
	@DeleteMapping(value = "delete/{id}")
	public void remove(@PathVariable int id) {
	    service.delete(id);
	}


}
