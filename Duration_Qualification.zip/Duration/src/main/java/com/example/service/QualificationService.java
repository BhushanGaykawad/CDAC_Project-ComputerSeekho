package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.example.entity.CourseDuration;
import com.example.entity.Qualification;
import com.example.repository.DurationRespository;
import com.example.repository.QualificationRepository;


@Service
public class QualificationService  
{
	@Autowired
	QualificationRepository repository;
	
	public List<Qualification>getQualification()
	{
		return (List<Qualification>) repository.findAll();
	}

	public Qualification addQualification(Qualification group) {
		// TODO Auto-generated method stub
		return repository.save(group);
	}
	
	public void delete(int id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}

	

}
