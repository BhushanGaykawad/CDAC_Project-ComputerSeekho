package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.example.entity.CourseDuration;
import com.example.repository.DurationRespository;


@Service
public class DurationService  
{
	@Autowired
	DurationRespository repository;
	
	public List<CourseDuration>getDuration()
	{
		return (List<CourseDuration>) repository.findAll();
	}

	public CourseDuration addDuration(CourseDuration group) {
		// TODO Auto-generated method stub
		return repository.save(group);
	}
	
	public void delete(int id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}

	

}
