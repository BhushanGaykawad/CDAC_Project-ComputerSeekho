import { Link } from "react-router-dom"
export default function Home()
{
    return(
        <div>
            HOme
            <div>
            <Link to='/create'>RegisterUser</Link><br></br>
            <Link to='/logout'>Logout</Link>
            <Link to='/show'>Show_Staff</Link>
            </div>
        </div>
       
        
    )
}