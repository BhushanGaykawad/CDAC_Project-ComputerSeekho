import { useState,useEffect } from "react"

export default function ShowStaff()
{
    const[staff, setStaff]=useState([]);

    useEffect(()=>{
        fetch("http://localhost:8081/show")
        .then(res=>res.json())
        .then((result)=>{console.log(result);setStaff(result.demo);});
    }, []);
    return(
        <div>
            <h2>Staff Data</h2>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>staff_Id</th>
                        <th>Designation_id</th>
                        <th>Qualification_id</th>
                        <th>Experience</th>
                        <th>Contact_No</th>

                    </tr>
                </thead>
                <tbody>
                    { staff.map (emp=>(
                        <tr key={emp.email}>
                            <td>{emp.name}</td>
                            <td>{emp.email}</td>
                            <td>{emp.staff_Id}</td>
                            <td>{emp.Designation_id}</td>
                            <td>{emp.Qualification_id}</td>
                            <td>{emp.Experience}</td>
                            <td>{emp.Contact_No}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}