import { useNavigate } from 'react-router-dom';
import SignUpValidation from './SignUpValidation';
import { useEffect, useState } from 'react';


export default function SignUp() {
  let navigate=useNavigate();

  const [values, setValues] = useState({
    name: '',
    email: '',
    password: '',
    staff_id:'',
    designation_id:'',
    qualification_id:'',
    Experience:'',
    Contact_No:''
  });
  const [errors, setErrors] = useState({});
  const[staffrole, setStaffRole]=useState([]);
  const[designationRole,setDesignationRole]=useState([])
  const[qualification,setQualification]=useState([])

  useEffect(()=>{
    fetch("http://localhost:8081/qualification")
    .then(res=>res.json())
    .then((result)=>{console.log(result);setQualification(result.demo);});
}, []);
  
  useEffect(()=>{
    fetch("http://localhost:8081/designation")
    .then(res=>res.json())
    .then((result)=>{console.log(result);setDesignationRole(result.demo);});
}, []);

  useEffect(()=>{
    fetch("http://localhost:8081/staff")
    .then(res=>res.json())
    .then((result)=>{console.log(result);setStaffRole(result.demo);});
}, []);

  

  const handleInput = (event) => {
    
    setValues((prev) => ({ ...prev, [event.target.name]: event.target.value }));
    console.log(values);
  };


  const handleSubmit = (event) => {
    event.preventDefault();
    setErrors(SignUpValidation(values));
    console.log(JSON.stringify(values));

    if (errors.name === "" && errors.email === "" && errors.password === "") {
      fetch("http://localhost:8081/create", {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(values)
      })
        .then((data) => {
          console.log(data); 
        })
        .catch((error) => {
          console.error('There was a problem with the fetch operation:', error);
        });
        alert("Inserted");
        navigate('/home');

    }
   
  };

  return (
    <div>
      <h4>Registration_Of_New_Staff</h4>
      <form onSubmit={handleSubmit}>
        <label htmlFor="name">Name:</label>
        <input type="text" name="name" onChange={handleInput} /><br/><br/>
        {errors.name && <span>{errors.name}</span>}

        <label htmlFor="email">Email:</label>
        <input type="text" name="email" onChange={handleInput} /><br/><br/>
        {errors.email && <span>{errors.email}</span>}

        <label htmlFor="password">Password:</label>
        <input type="password" name="password" onChange={handleInput} /><br/><br/>
        {errors.password && <span>{errors.password}</span>}

        <label htmlFor="staff_id">staff_id:</label>
        <select name="staff_id" onChange={handleInput}>
        <option> selectOption</option>
            {staffrole?.map(emp=>(
              
                <option value={emp.staff_id}> {emp.role}</option>
            ))} 
        </select><br></br>
        
        
        <label htmlFor="designation_id">designation_id:</label>
        <select name="designation_id" onChange={handleInput}>
        <option> selectOption</option>
            {designationRole.map(emp=>(
                <option value={emp.designation_id}> {emp.designation}</option>
            ))} 
        </select><br></br>



        <label htmlFor="qualification_id">Qualification_id:</label>
        <select name="qualification_id" onChange={handleInput}>
        <option> selectOption</option>
            {qualification.map(emp=>(
                <option value={emp.qualification_id}> {emp.qualification}</option>
            ))} 
        </select> <br></br>



        <label htmlFor="Experience">Experience:</label>
        <input type="text" name="Experience" onChange={handleInput} /><br/><br/>

        <label htmlFor="Contact_No">Contact_No:</label>
        <input type="text" name="Contact_No" onChange={handleInput} /><br/><br/>

      

        <label htmlFor="create">create</label>
        <button>create</button>
       
      </form>
    </div>
  );
}
