import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import reportWebVitals from './reportWebVitals';
import Login from './Login';
import SignUp from './SignUp';
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import Home from './Home';
import Logout from './Logout';
import ShowStaff from './ShowStaff';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter>
  <Routes>
    <Route path="/login" element={<Login/>}></Route>
    <Route path="/create" element={<SignUp/>}></Route>
    <Route path="/home" element={<Home/>}></Route>
    <Route path="/logout" element={<Logout />}></Route>
    <Route path="/show/" element={<ShowStaff />}></Route>
  </Routes>
  </BrowserRouter>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
