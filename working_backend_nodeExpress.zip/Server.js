const express =require ("express");
const mysql =require('mysql2');
const cors=require('cors');
const app=express();
app.use(cors());
app.use(express.json());

const db=mysql.createConnection(
  {
      host:'localhost',
      user:'bhushan',
      password:"Bhushan@25",
      database:"bit",
      port:'3306'
  })
  db.connect((err) => {
    if (err) {
      console.error('Error connecting to MySQL:', err);
      return;
    }
    console.log('Connected to MySQL database');
  });
app.post('/create',(req,res)=>
{

    const sql="insert into login (`name`,`email`,`password`,`staff_id`,`designation_id`, `Qualification_id`,`Experience`,`Contact_No`) values(?)";
    const values=[
        req.body.name,
        req.body.email,
        req.body.password,
        req.body.staff_id,
        req.body.designation_id,
        req.body.Qualification_id,
        req.body.Experience,
        req.body.Contact_No,
    ]
    db.query(sql,[values],(err,data)=>{
        if(err)
        {
          
            return res.json("Error");
        }
        return res.json(data);
    })

})

app.post('/login', (req, res) => {
    const sql = "SELECT * FROM login WHERE `email` = ? AND `password` = ?";
    const values = [req.body.email, req.body.password];
  
    db.query(sql, values, (err, data) => {
      if (err) {
        return res.status(500).json({ status: 'Error1' });
      }
      if (data.length > 0) {
        return res.json({ status: 'Success', user: data[0] });
      } else {
        return res.status(401).json({ status: 'Fail' });
      }
    });
  });

  app.get('/show',(req,res)=>
  {
    const sql="select name,email,staff_id,designation_id,Qualification_id,Experience,Contact_No from login";
    db.query(sql,(err,data)=>{
      if(err)
      {
        return res.status(500).json({status:"Error"});
      }
      else{
        return res.status(200).json({status:"Success",demo:data})
      }
    })
  });

  app.get('/staff',(req,res)=>
  {
    const sql="select staff_id,role from homestaff";
    db.query(sql,(err,data)=>{
      if(err)
      {
        return res.status(500).json({status:"Error"});
      }
      else{
        return res.status(200).json({status:"Success",demo:data})
      }
    })
  });
  
  app.get('/designation',(req,res)=>
  {
    const sql="select designation_id,designation from designation";

    db.query(sql,(err,data)=>{
      if(err)
      {
        return res.status(500).json({status:"Error"});
      }
      else{
        return res.status(200).json({status:"Success",demo:data})
      }
    })
  });
  app.get('/qualification',(req,res)=>
  {
    const sql="select qualification_id,qualification from qualification";

    db.query(sql,(err,data)=>{
      if(err)
      {
        return res.status(500).json({status:"Error"});
      }
      else{
        return res.status(200).json({status:"Success",demo:data})
      }
    })
  });

  app.listen(8081,()=>{
      console.log("Listening");
  })