const express =require ("express");
const mysql =require('mysql2');
const cors=require('cors');
const app=express();
app.use(cors());
app.use(express.json());

const db=mysql.createConnection(
  {
      host:'localhost',
      user:'bhushan',
      password:"Bhushan@25",
      database:"bit",
      port:'3306'
  })
  db.connect((err) => {
    if (err) {
      console.error('Error connecting to MySQL:', err);
      return;
    }
    console.log('Connected to MySQL database');
  });

app.post('/create',(req,res)=>
{

    const sql="insert into login (`name`,`email`,`password`,`staff_id`,`designation_id`, `Qualification_id`,`Experience`,`Contact_No`,`age_Group_id`,`duration_id`) values(?)";
    const values=[
        req.body.name,
        req.body.email,
        req.body.password,
        req.body.staff_id,
        req.body.designation_id,
        req.body.Qualification_id,
        req.body.Experience,
        req.body.Contact_No,
        req.body.age_Group_id,
        req.body.duration_id,
    ]
    db.query(sql,[values],(err,data)=>{
        if(err)
        {
          
            return res.json("Error");
        }
        return res.json(data);
    })

})


app.post('/enquiry', (req, res) => {
  const sql = "INSERT INTO Enquiry (`course_id`,`enquirer_name`,`qualification`,`contact_no`,`email`,`enquiry_date`,`enquiry_source_id`,`student_name`,`location_id`,`enquirer_query`,`closure_id`,`next_followup_date`,`staff_id`,`date_of_birth`,`other_closure_reason`) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
  const values = [
    req.body.course_id, 
    req.body.enquirer_name,
    req.body.qualification,
    req.body.contact_no,
    req.body.email,
    req.body.enquiry_date,
    req.body.enquiry_source_id,
    req.body.student_name,
    req.body.location_id,
    req.body.enquirer_query,
    req.body.closure_id,
    req.body.next_followup_date,
    req.body.staff_id,
    req.body.date_of_birth,
    req.body.other_closure_reason,
   
    
  ];

  db.query(sql, values, (err, data) => {
    if (err) {
      return res.status(500).json({ status: 'Error1' });
    }
    if (data.affectedRows > 0) {
      return res.json({ status: 'Success', user: data[0] });
    } else {
      return res.status(401).json({ status: 'Fail' });
    }
  });
});

app.post('/login', (req, res) => {
    const sql = "SELECT * FROM login WHERE `email` = ? AND `password` = ?";
    const values = [req.body.email, req.body.password];
  
    db.query(sql, values, (err, data) => {
      if (err) {
        return res.status(500).json({ status: 'Error1' });
      }
      if (data.length > 0) {
        return res.json({ status: 'Success', user: data[0] });
      } else {
        return res.status(401).json({ status: 'Fail' });
      }
    });
  });

  app.get('/show',(req,res)=>
  {
    const sql="select name,email,staff_id,designation_id,Qualification_id,Experience,Contact_No from login";
    db.query(sql,(err,data)=>{
      if(err)
      {
        return res.status(500).json({status:"Error"});
      }
      else{
        return res.status(200).json({status:"Success",demo:data})
      }
    })
  });

  app.get('/staff',(req,res)=>
  {
    const sql="select staff_id,role from homestaff";
    db.query(sql,(err,data)=>{
      if(err)
      {
        return res.status(500).json({status:"Error"});
      }
      else{
        return res.status(200).json({status:"Success",demo:data})
      }
    })
  });

  app.get('/agegroup',(req,res)=>
  {
    const sql="select age_group_id, age_group from age_group";
    db.query(sql,(err,data)=>{
      if(err)
      {
        return res.status(500).json({status:"Error"});
      }
      else{
        return res.status(200).json({status:"Success",demo:data})
      }
    })
  });
  
  app.get('/designation',(req,res)=>
  {
    const sql="select designation_id,designation from designation";

    db.query(sql,(err,data)=>{
      if(err)
      {
        return res.status(500).json({status:"Error"});
      }
      else{
        return res.status(200).json({status:"Success",demo:data})
      }
    })
  });
  app.get('/qualification',(req,res)=>
  {
    const sql="select qualification_id,qualification from qualification";

    db.query(sql,(err,data)=>{
      if(err)
      {
        return res.status(500).json({status:"Error"});
      }
      else{
        return res.status(200).json({status:"Success",demo:data})
      }
    })
  });

  app.listen(8081,()=>{
      console.log("Listening");
  })